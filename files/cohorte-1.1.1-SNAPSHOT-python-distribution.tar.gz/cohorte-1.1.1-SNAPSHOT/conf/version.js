{
	"distribution" : "cohorte-python-distribution",
	"stage" : "dev",
	"version" : "1.1.1",
	"timestamp" : "20150824-155542"
}
