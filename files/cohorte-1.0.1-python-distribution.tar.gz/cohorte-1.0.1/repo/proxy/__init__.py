#!/usr/bin/env python
# -- Content-Encoding: UTF-8 --
"""
COHORTE Node Composer HTTP Service Proxy

:author: Bassem Debbabi
:license: Apache License v2
"""

# Documentation strings format
__docformat__ = "restructuredtext en"

# ------------------------------------------------------------------------------
# Service specifications
