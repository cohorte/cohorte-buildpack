{
	"distribution" : "cohorte-python-distribution",
	"stage" : "release",
	"version" : "1.0.1",
	"timestamp" : "20150602-103138"
}
