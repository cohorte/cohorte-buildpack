Cohorte Platform Distributions
==============================

This repository contains scripts allowing the generation of the different Cohorte distributions (runtime).


