python-cocoa
############

Python 3 version of the python-cocoa project from:
`python-cocoa on Google Code <https://code.google.com/p/cocoa-python/>`_.
This library is released under the terms of the
`New BSD license <http://opensource.org/licenses/BSD-3-Clause>`_.

It allows to access Cocoa methods using ctypes instead of a compiled library.

**Note:** This library should be moved to the cohorte-3rdpary project,
after being set Python "2-3" compatible.
