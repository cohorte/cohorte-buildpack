#!/usr/bin/env python
# -- Content-Encoding: UTF-8 --
"""
COHORTE REST Admin API

:author: Bassem Debbabi
:license: Apache License v2
"""

# Documentation strings format
__docformat__ = "restructuredtext en"

# ------------------------------------------------------------------------------
# Service specifications
