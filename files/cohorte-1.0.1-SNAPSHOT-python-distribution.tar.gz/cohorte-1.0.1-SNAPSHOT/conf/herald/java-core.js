/**
 * Configuration for Herald
 */
{
	/*
	 * Herald core bundles
	 */
	"bundles" : [ {
		"name" : "org.cohorte.herald.api"
	}, {
		"name" : "org.cohorte.herald.core"
	} ]
}
