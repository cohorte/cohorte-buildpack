/**
 * Configuration for Herald
 */
{
	/*
	 * Herald core bundles
	 */
	"bundles" : [ {
		"name" : "herald.core"
	}, {
		"name" : "herald.directory"
	}, {
		"name" : "herald.shell"
	}, {
		"name" : "herald.remote.discovery"
	}, {
		"name" : "herald.remote.herald_jabsorbrpc"
	} ]
}
