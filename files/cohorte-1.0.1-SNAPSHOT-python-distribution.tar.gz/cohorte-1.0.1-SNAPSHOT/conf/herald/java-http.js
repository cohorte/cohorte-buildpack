/**
 * Configuration for Herald HTTP transport
 */
{
	/*
	 * Herald HTTP transport bundles
	 */
	"bundles" : [ {
		"name" : "org.cohorte.herald.http"
	} ]
}
