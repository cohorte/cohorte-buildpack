{
	"distribution" : "cohorte-python-distribution",
	"stage" : "dev",
	"version" : "1.0.1",
	"timestamp" : "20150525-173700"
}
